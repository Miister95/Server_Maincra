local default = require("tacz_default_state_machine")
local STATIC_TRACK_LINE   = default.STATIC_TRACK_LINE
local MAIN_TRACK          = default.MAIN_TRACK
local main_track_states   = default.main_track_states
local static_track_top    = default.static_track_top
local GUN_KICK_TRACK_LINE = default.GUN_KICK_TRACK_LINE

local inspect_state = setmetatable({}, { __index = main_track_states.inspect })
local idle_state    = setmetatable({}, { __index = main_track_states.idle })
local start_state   = setmetatable({}, { __index = main_track_states.start })

local function increment(obj)
    obj.value = obj.value + 1
    return obj.value - 1
end

local FIRE_MODE_TRACK   = increment(static_track_top)
local SWITCH_MODE_TRACK = increment(static_track_top)

local SEMI = 1  -- Semi-automatic mode
local AUTO = 0  -- Full-automatic mode

local function isNoAmmo(context)
    return (not context:hasBulletInBarrel()) and (context:getAmmoCount() <= 0)
end

local function runReloadAnimation(context)
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    local ext   = context:getMagExtentLevel()
    local mode  = context:getFireMode()

    if isNoAmmo(context) then
        local prefix = "reload_empty"
        if mode == SEMI then
            prefix = prefix .. "_semi"
        elseif mode == AUTO then
            prefix = prefix .. "_auto"
        end
        if ext == 1 then
            prefix = prefix .. "_xmag_1"
        elseif ext == 2 or ext == 3 then
            prefix = prefix .. "_xmag_23"
        end
        context:runAnimation(prefix, track, false, PLAY_ONCE_STOP, 0.2)
    else
        local prefix = "reload_tactical"
        if mode == SEMI then
            prefix = prefix .. "_semi"
        elseif mode == AUTO then
            prefix = prefix .. "_auto"
        end
        
        if ext == 0 then
            context:runAnimation(prefix, track, false, PLAY_ONCE_STOP, 0.2)
        elseif ext == 1 then
            context:runAnimation(prefix .. "_xmag_1", track, false, PLAY_ONCE_STOP, 0.2)
        elseif ext == 2 or ext == 3 then
            context:runAnimation(prefix .. "_xmag_23", track, false, PLAY_ONCE_STOP, 0.2)
        else
            context:runAnimation(prefix, track, false, PLAY_ONCE_STOP, 0.2)
        end
    end
end

local function runInspectAnimation(context)
    local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
    local ext   = context:getMagExtentLevel()

    if isNoAmmo(context) then
        if ext == 0 then
            context:runAnimation("inspect_empty", track, false, PLAY_ONCE_STOP, 0.2)
        elseif ext == 1 then
            context:runAnimation("inspect_empty_xmag_1", track, false, PLAY_ONCE_STOP, 0.2)
        elseif ext == 2 or ext == 3 then
            context:runAnimation("inspect_empty_xmag_23", track, false, PLAY_ONCE_STOP, 0.2)
        else
            context:runAnimation("inspect_empty", track, false, PLAY_ONCE_STOP, 0.2)
        end
    else
        if ext == 0 then
            context:runAnimation("inspect", track, false, PLAY_ONCE_STOP, 0.2)
        elseif ext == 1 then
            context:runAnimation("inspect_xmag_1", track, false, PLAY_ONCE_STOP, 0.2)
        elseif ext == 2 or ext == 3 then
            context:runAnimation("inspect_xmag_23", track, false, PLAY_ONCE_STOP, 0.2)
        else
            context:runAnimation("inspect", track, false, PLAY_ONCE_STOP, 0.2)
        end
    end
end

function idle_state.transition(this, context, input)
    if input == INPUT_RELOAD then
        runReloadAnimation(context)
        return this.main_track_states.idle
    end

    if input == INPUT_PUT_AWAY then
        local put_away_time = context:getPutAwayTime()
        local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
        context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK))
        context:runAnimation("put_away", track, false, PLAY_ONCE_HOLD, put_away_time * 0.75)
        context:setAnimationProgress(track, 1, true)
        context:adjustAnimationProgress(track, -put_away_time, false)
        return main_track_states.final
    end

    if input == INPUT_INSPECT then
        runInspectAnimation(context)
        return inspect_state
    end

    return main_track_states.idle.transition(this, context, input)
end

function start_state.transition(this, context, input)
    if input == INPUT_DRAW then
        local track = context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK)
        local mode = context:getFireMode()
        local anim = (mode == SEMI) and "draw_semi" or "draw_auto"
        context:runAnimation(anim, track, false, PLAY_ONCE_STOP, 0)
        return this.main_track_states.idle
    end
end

local gun_kick_state = setmetatable({}, { __index = default.gun_kick_state })

function gun_kick_state.transition(this, context, input)
    local mode = context:getFireMode()

    if input == INPUT_SHOOT then
        if mode == SEMI then
            context:runAnimation("shoot1",
                context:findIdleTrack(GUN_KICK_TRACK_LINE, false),
                true, PLAY_ONCE_STOP, 0)
        elseif mode == AUTO then
            context:popShellFrom(0)
            context:runAnimation("shoot2",
                context:findIdleTrack(GUN_KICK_TRACK_LINE, false),
                true, PLAY_ONCE_STOP, 0)
        end
    end

    return nil
end

local fire_mode_state = {
    semi  = {},
    auto  = {},
    draw  = {}
}

function fire_mode_state.draw.update(this, context)
    context:trigger(this.INPUT_MODE_DRAW)
end

function fire_mode_state.draw.transition(this, context, input)
    if input == this.INPUT_MODE_DRAW then
        local mode = context:getFireMode()
        if mode == SEMI then
            context:runAnimation("static_semi",
                context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK),
                true, PLAY_ONCE_HOLD, 0)
            return fire_mode_state.semi
        elseif mode == AUTO then
            context:runAnimation("static_auto",
                context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK),
                true, PLAY_ONCE_HOLD, 0)
            return fire_mode_state.auto
        end
    end
end

function fire_mode_state.semi.update(this, context)
    local track = context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK)
    if context:isHolding(track) then
        context:runAnimation("static_semi", track, true, PLAY_ONCE_HOLD, 0)
    end
    if context:getFireMode() == AUTO then
        context:trigger(this.INPUT_MODE_AUTO)
    end
end

function fire_mode_state.semi.transition(this, context, input)
    if input == this.INPUT_MODE_AUTO then
        context:runAnimation("switch_auto",
            context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK),
            false, PLAY_ONCE_STOP, 0)
        return fire_mode_state.auto
    end
    if input == INPUT_SHOOT or input == INPUT_RELOAD or input == INPUT_INSPECT then
        context:stopAnimation(
            context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK))
    end
end

function fire_mode_state.auto.update(this, context)
    local track = context:getTrack(STATIC_TRACK_LINE, FIRE_MODE_TRACK)
    if context:isHolding(track) then
        context:runAnimation("static_auto", track, true, PLAY_ONCE_HOLD, 0)
    end
    if context:getFireMode() == SEMI then
        context:trigger(this.INPUT_MODE_SEMI)
    end
end

function fire_mode_state.auto.transition(this, context, input)
    if input == this.INPUT_MODE_SEMI then
        context:runAnimation("switch_semi",
            context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK),
            false, PLAY_ONCE_STOP, 0)
        return fire_mode_state.semi
    end
    if input == INPUT_SHOOT or input == INPUT_RELOAD or input == INPUT_INSPECT then
        context:stopAnimation(
            context:getTrack(STATIC_TRACK_LINE, SWITCH_MODE_TRACK))
    end
end

function inspect_state.transition(this, context, input)
    if input == INPUT_FIRE_SELECT then
        context:stopAnimation(context:getTrack(STATIC_TRACK_LINE, MAIN_TRACK))
        return this.main_track_states.idle
    end
    return main_track_states.inspect.transition(this, context, input)
end

local M = setmetatable({
    main_track_states = setmetatable({
        idle    = idle_state,
        inspect = inspect_state,
        start   = start_state
    }, { __index = main_track_states }),

    FIRE_MODE_TRACK   = FIRE_MODE_TRACK,
    SWITCH_MODE_TRACK = SWITCH_MODE_TRACK,

    INPUT_MODE_SEMI   = "input_mode_semi",
    INPUT_MODE_AUTO   = "input_mode_auto",
    INPUT_MODE_DRAW   = "input_mode_draw",

    fire_mode_state = fire_mode_state,
    gun_kick_state  = gun_kick_state
}, { __index = default })

function M:initialize(context)
    default.initialize(self, context)
end

function M:states()
    return {
        self.base_track_state,
        self.bolt_caught_states.normal,
        self.main_track_states.start,
        self.gun_kick_state,
        self.movement_track_states.idle,
        self.ADS_states.normal,
        self.slide_states.normal,
        self.fire_mode_state.draw
    }
end

return M